$(document).ready(function () {
    const contentSection = document.querySelector('.content');

    const API_URLS = {
        getPort: contentSection.dataset.getPortUrl,
        getSni: contentSection.dataset.getSniUrl,
        checkObfs: contentSection.dataset.checkObfsUrl,
        enableObfs: contentSection.dataset.enableObfsUrl,
        disableObfs: contentSection.dataset.disableObfsUrl,
        setPortTemplate: contentSection.dataset.setPortUrlTemplate,
        setSniTemplate: contentSection.dataset.setSniUrlTemplate,
        updateGeoTemplate: contentSection.dataset.updateGeoUrlTemplate
    };

    // --- Функция перевода ошибок с бэкенда ---
    function translateError(errorMsg) {
        if (!errorMsg) return "Произошла неизвестная ошибка.";
        if (typeof errorMsg !== 'string') return "Ошибка формата данных.";

        // Системные ошибки
        if (errorMsg.includes("failed with exit code")) return "Ошибка выполнения команды на сервере.";
        if (errorMsg.includes("No such file or directory")) return "Файл конфигурации не найден.";
        if (errorMsg.includes("Permission denied")) return "Отказано в доступе (ошибка прав).";
        if (errorMsg.includes("Address already in use")) return "Этот порт уже занят другой программой.";
        
        // Ошибки валидации
        if (errorMsg.includes("Invalid port")) return "Указан недопустимый порт.";
        if (errorMsg.includes("Invalid domain")) return "Некорректный домен.";
        
        return errorMsg; // Возвращаем оригинал, если перевод не найден
    }

    function isValidDomain(domain) {
        if (!domain) return false;
        const lowerDomain = domain.toLowerCase();
        return !lowerDomain.startsWith("http://") && !lowerDomain.startsWith("https://");
    }

    function isValidPort(port) {
        if (!port) return false;
        return /^[0-9]+$/.test(port) && parseInt(port) > 0 && parseInt(port) <= 65535;
    }

    function confirmAction(actionName, callback) {
        Swal.fire({
            title: `Вы уверены?`,
            text: `Вы действительно хотите ${actionName}?`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Да, выполнить!",
            cancelButtonText: "Отмена"
        }).then((result) => {
            if (result.isConfirmed) {
                callback();
            }
        });
    }

    function sendRequest(url, type, data, successMessage, buttonSelector, showReload = true, postSuccessCallback = null) {
        $.ajax({
            url: url,
            type: type,
            contentType: "application/json",
            data: data ? JSON.stringify(data) : null,
            beforeSend: function() {
                if (buttonSelector) {
                    $(buttonSelector).prop('disabled', true);
                     $(buttonSelector + ' .spinner-border').show();
                }
            },
            success: function (response) {
    if (window.showToast) {
        showToast("success", "Успешно!", successMessage);
        if (showReload) {
            setTimeout(() => location.reload(), 800);
        } else if (postSuccessCallback) {
            postSuccessCallback(response);
        }
    } else {
        Swal.fire("Успешно!", successMessage, "success").then(() => {
            if (showReload) {
                location.reload();
            } else if (postSuccessCallback) {
                postSuccessCallback(response);
            }
        });
    }
},
            error: function (xhr, status, error) {
                let errorMessage = "Произошла непредвиденная ошибка.";
                if (xhr.responseJSON && xhr.responseJSON.detail) {
                    const detail = xhr.responseJSON.detail;
                    if (Array.isArray(detail)) {
                        errorMessage = detail.map(err => `Ошибка в '${err.loc[1]}': ${err.msg}`).join('\n');
                    } else if (typeof detail === 'string') {
                        let userMessage = detail;
                        // Очистка технических деталей Python, если они есть
                        const failMarker = 'failed with exit code';
                        const markerIndex = detail.indexOf(failMarker);
                        if (markerIndex > -1) {
                            const colonIndex = detail.indexOf(':', markerIndex);
                            if (colonIndex > -1) {
                                userMessage = detail.substring(colonIndex + 1).trim();
                            }
                        }
                        errorMessage = userMessage;
                    }
                }
                // Применяем перевод
                if (window.showToast) { showToast("error", "Ошибка!", translateError(errorMessage), { timer: 5000 }); } else { Swal.fire("Ошибка!", translateError(errorMessage), "error"); }
                console.error("AJAX Error:", status, error, xhr.responseText);
            },
            complete: function() {
                if (buttonSelector) {
                    $(buttonSelector).prop('disabled', false);
                    $(buttonSelector + ' .spinner-border').hide();
                }
            }
        });
    }

    function validateForm(formId) {
        let isValid = true;
        $(`#${formId} .form-control:visible`).each(function () {
            const input = $(this);
            const id = input.attr('id');
            let fieldValid = true;

            if (id === 'sni_domain') {
                fieldValid = isValidDomain(input.val());
            } else if (id === 'hysteria_port') {
                fieldValid = isValidPort(input.val());
            }

            if (!fieldValid) {
                input.addClass('is-invalid');
                isValid = false;
            } else {
                input.removeClass('is-invalid');
            }
        });
        return isValid;
    }

    function initUI() {
        $.ajax({
            url: API_URLS.getPort,
            type: "GET",
            success: function (data) {
                $("#hysteria_port").val(data.port || "");
            },
            error: function (xhr, status, error) {
                console.error("Failed to fetch port:", error, xhr.responseText);
            }
        });

        $.ajax({
            url: API_URLS.getSni,
            type: "GET",
            success: function (data) {
                $("#sni_domain").val(data.sni || "");
            },
            error: function (xhr, status, error) {
                console.error("Failed to fetch SNI domain:", error, xhr.responseText);
            }
        });
    }

    function fetchObfsStatus() {
        $.ajax({
            url: API_URLS.checkObfs,
            type: "GET",
            success: function (data) {
                updateObfsUI(data.obfs);
            },
            error: function (xhr, status, error) {
                $("#obfs_status_message").html('<span class="text-danger">Не удалось получить статус OBFS.</span>');
                console.error("Failed to fetch OBFS status:", error, xhr.responseText);
                 $("#obfs_enable_btn").hide();
                $("#obfs_disable_btn").hide();
            }
        });
    }

    function updateObfsUI(statusMessage) {
        let displayMessage = statusMessage;
        
        // Перевод статусов OBFS
        if (statusMessage && statusMessage.includes("active")) {
             if (statusMessage.includes("not active")) {
                 displayMessage = "OBFS выключен.";
             } else {
                 displayMessage = "OBFS активен.";
             }
        } else if (statusMessage === "OBFS is active.") { 
             displayMessage = "OBFS активен.";
        } else if (statusMessage === "OBFS is not active.") {
             displayMessage = "OBFS выключен.";
        }

        $("#obfs_status_message").text(displayMessage);
        
        // Логика UI
        if (displayMessage === "OBFS активен.") {
            $("#obfs_enable_btn").hide();
            $("#obfs_disable_btn").show();
            $("#obfs_status_container").removeClass("border-danger border-warning alert-danger alert-warning").addClass("border-success alert-success");
        } else {
            $("#obfs_enable_btn").show();
            $("#obfs_disable_btn").hide();
            $("#obfs_status_container").removeClass("border-success border-danger alert-success alert-danger").addClass("border-warning alert-warning");
        }
    }

    function enableObfs() {
        confirmAction("включить OBFS", function () {
            sendRequest(
                API_URLS.enableObfs,
                "GET",
                null,
                "OBFS успешно включен!",
                "#obfs_enable_btn",
                false,
                fetchObfsStatus
            );
        });
    }

    function disableObfs() {
        confirmAction("выключить OBFS", function () {
            sendRequest(
                API_URLS.disableObfs,
                "GET",
                null,
                "OBFS успешно выключен!",
                "#obfs_disable_btn",
                false,
                fetchObfsStatus
            );
        });
    }

    function changePort() {
        if (!validateForm('port_form')) return;
        const port = $("#hysteria_port").val();
        const url = API_URLS.setPortTemplate.replace("PORT_PLACEHOLDER", port);
        confirmAction("изменить порт", function () {
            sendRequest(url, "GET", null, "Порт успешно изменен!", "#port_change");
        });
    }

    function changeSNI() {
        if (!validateForm('sni_form')) return;
        const domain = $("#sni_domain").val();
        const url = API_URLS.setSniTemplate.replace("SNI_PLACEHOLDER", domain);
        confirmAction("изменить SNI", function () {
            sendRequest(url, "GET", null, "SNI успешно изменен!", "#sni_change");
        });
    }

    function updateGeo(country) {
        const countryNames = {
            'iran': 'Ирана',
            'china': 'Китая',
            'russia': 'России'
        };
        const countryName = countryNames[country] || country;
        const buttonId = `#geo_update_${country}`;
        const url = API_URLS.updateGeoTemplate.replace('COUNTRY_PLACEHOLDER', country);

        confirmAction(`обновить Geo-файлы для ${countryName}`, function () {
            sendRequest(
                url,
                "GET",
                null,
                `Geo-файлы для ${countryName} успешно обновлены!`,
                buttonId,
                false,
                null
            );
        });
    }

    initUI();
    fetchObfsStatus();

    $("#port_change").on("click", changePort);
    $("#sni_change").on("click", changeSNI);
    $("#obfs_enable_btn").on("click", enableObfs);
    $("#obfs_disable_btn").on("click", disableObfs);
    $("#geo_update_iran").on("click", function() { updateGeo('iran'); });
    $("#geo_update_china").on("click", function() { updateGeo('china'); });
    $("#geo_update_russia").on("click", function() { updateGeo('russia'); });

    $('#sni_domain').on('input', function () {
        if (isValidDomain($(this).val())) {
            $(this).removeClass('is-invalid');
        } else if ($(this).val().trim() !== "") {
            $(this).addClass('is-invalid');
        } else {
             $(this).removeClass('is-invalid');
        }
    });

    $('#hysteria_port').on('input', function () {
         if (isValidPort($(this).val())) {
            $(this).removeClass('is-invalid');
        } else if ($(this).val().trim() !== "") {
            $(this).addClass('is-invalid');
        } else {
             $(this).removeClass('is-invalid');
        }
    });
});