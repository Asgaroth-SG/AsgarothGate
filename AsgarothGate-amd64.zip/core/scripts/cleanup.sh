#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${RED}!!! ВНИМАНИЕ !!!${NC}"
echo -e "Вы действительно хотите ПОЛНОСТЬЮ удалить Asgaroth Gate?"
echo -e "Все пользователи, настройки и базы данных будут уничтожены."
read -p "Вы уверены? (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Отмена."
    exit 1
fi

echo -e "\n${YELLOW}[1/6] Остановка сервисов...${NC}"
SERVICES=(
    "hysteria-server.service"
    "hysteria-auth.service"
    "hysteria-webpanel.service"
    "hysteria-telegram-bot.service"
    "hysteria-scheduler.service"
    "hysteria-ip-limit.service"
    "hysteria-normal-sub.service"
    "hysteria-caddy.service"
    "hysteria-caddy-normalsub.service"
    "wg-quick@wgcf.service"
)

for service in "${SERVICES[@]}"; do
    if systemctl is-active --quiet "$service" || systemctl is-enabled --quiet "$service"; then
        echo "Stopping $service..."
        systemctl stop "$service" 2>/dev/null
        systemctl disable "$service" 2>/dev/null
    fi
	
    if [ -f "/etc/systemd/system/$service" ]; then
        rm "/etc/systemd/system/$service"
    fi
done

systemctl daemon-reload

echo -e "${YELLOW}[2/6] Очистка базы данных...${NC}"
if command -v mongosh &> /dev/null; then
    mongosh --quiet --eval "db.getSiblingDB('asgaroth_panel').dropDatabase()"
    echo -e "${GREEN}Базы данных удалены.${NC}"
else
    echo -e "${RED}MongoDB shell не найден, пропуск удаления БД.${NC}"
fi

echo -e "${YELLOW}[3/6] Удаление файлов...${NC}"
rm -rf /etc/hysteria
rm -rf /opt/hysbackup
rm -f /root/menu.sh
rm -f /var/log/hysteria_scheduler.log

echo -e "${YELLOW}[4/6] Очистка Cron...${NC}"
crontab -l | grep -v "hysteria" | crontab -

echo -e "${YELLOW}[5/6] Удаление пользователя hysteria...${NC}"
if id "hysteria" &>/dev/null; then
    userdel hysteria
fi

echo -e "${YELLOW}[6/6] Сброс правил iptables...${NC}"

echo -e "\n${GREEN}✅ Удаление панели Asgaroth Gate завершено.${NC}"